export interface Tenant {
  id: string;
  name: string;
  phone: string;
  email: string;
  joinDate: string;
  unitId: string;
}

export interface RentCollection {
  id: string;
  tenantId: string;
  amount: number;
  date: string;
  type: 'RENT' | 'ADVANCE' | 'MAINTENANCE';
  status: 'PAID' | 'PENDING' | 'OVERDUE';
}

export interface Unit {
  id: string;
  number: string;
  floor: string;
  status: 'VACANT' | 'OCCUPIED';
  rentAmount: number;
  maintenanceCharge: number;
  parkingSlots: string[];
}

export interface Utility {
  id: string;
  unitId: string;
  type: 'ELECTRICITY' | 'WATER' | 'TAX' | 'MISC';
  amount: number;
  date: string;
  status: 'PAID' | 'PENDING';
  description?: string;
}

export interface ParkingSlot {
  id: string;
  number: string;
  type: 'CAR' | 'BIKE';
  status: 'OCCUPIED' | 'VACANT';
  unitId?: string;
}