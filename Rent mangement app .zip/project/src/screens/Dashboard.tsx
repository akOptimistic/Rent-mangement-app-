import React from 'react';
import { View, Text, ScrollView } from 'react-native';
import { useSelector } from 'react-redux';
import { RootState } from '../store/store';

const Dashboard = () => {
  const units = useSelector((state: RootState) => state.units.units);
  const rentCollections = useSelector((state: RootState) => state.rentCollections.collections);
  const tenants = useSelector((state: RootState) => state.tenants.tenants);

  const totalUnits = units.length;
  const occupiedUnits = units.filter(unit => unit.status === 'OCCUPIED').length;
  const vacantUnits = totalUnits - occupiedUnits;
  
  const totalRentCollected = rentCollections
    .filter(rc => rc.status === 'PAID')
    .reduce((sum, rc) => sum + rc.amount, 0);

  return (
    <ScrollView className="flex-1 bg-gray-100">
      <View className="p-4">
        <Text className="text-2xl font-bold mb-6">Dashboard</Text>
        
        {/* Summary Cards */}
        <View className="flex-row flex-wrap justify-between">
          <View className="bg-white p-4 rounded-lg w-[48%] mb-4">
            <Text className="text-gray-600">Total Units</Text>
            <Text className="text-2xl font-bold">{totalUnits}</Text>
          </View>
          
          <View className="bg-white p-4 rounded-lg w-[48%] mb-4">
            <Text className="text-gray-600">Occupied Units</Text>
            <Text className="text-2xl font-bold">{occupiedUnits}</Text>
          </View>
          
          <View className="bg-white p-4 rounded-lg w-[48%] mb-4">
            <Text className="text-gray-600">Vacant Units</Text>
            <Text className="text-2xl font-bold">{vacantUnits}</Text>
          </View>
          
          <View className="bg-white p-4 rounded-lg w-[48%] mb-4">
            <Text className="text-gray-600">Total Tenants</Text>
            <Text className="text-2xl font-bold">{tenants.length}</Text>
          </View>
        </View>

        {/* Revenue Overview */}
        <View className="bg-white p-4 rounded-lg mt-4">
          <Text className="text-xl font-bold mb-2">Revenue Overview</Text>
          <Text className="text-gray-600">Total Rent Collected</Text>
          <Text className="text-2xl font-bold">₹{totalRentCollected}</Text>
        </View>
      </View>
    </ScrollView>
  );
};

export default Dashboard;