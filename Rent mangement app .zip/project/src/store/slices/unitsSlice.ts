import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { Unit } from '../../types';

interface UnitsState {
  units: Unit[];
  loading: boolean;
  error: string | null;
}

const initialState: UnitsState = {
  units: [],
  loading: false,
  error: null,
};

const unitsSlice = createSlice({
  name: 'units',
  initialState,
  reducers: {
    addUnit: (state, action: PayloadAction<Unit>) => {
      state.units.push(action.payload);
    },
    updateUnit: (state, action: PayloadAction<Unit>) => {
      const index = state.units.findIndex(u => u.id === action.payload.id);
      if (index !== -1) {
        state.units[index] = action.payload;
      }
    },
    removeUnit: (state, action: PayloadAction<string>) => {
      state.units = state.units.filter(u => u.id !== action.payload);
    },
  },
});

export const { addUnit, updateUnit, removeUnit } = unitsSlice.actions;
export default unitsSlice.reducer;