import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { ParkingSlot } from '../../types';

interface ParkingState {
  slots: ParkingSlot[];
  loading: boolean;
  error: string | null;
}

const initialState: ParkingState = {
  slots: [],
  loading: false,
  error: null,
};

const parkingSlice = createSlice({
  name: 'parking',
  initialState,
  reducers: {
    addSlot: (state, action: PayloadAction<ParkingSlot>) => {
      state.slots.push(action.payload);
    },
    updateSlot: (state, action: PayloadAction<ParkingSlot>) => {
      const index = state.slots.findIndex(s => s.id === action.payload.id);
      if (index !== -1) {
        state.slots[index] = action.payload;
      }
    },
    removeSlot: (state, action: PayloadAction<string>) => {
      state.slots = state.slots.filter(s => s.id !== action.payload);
    },
  },
});

export const { addSlot, updateSlot, removeSlot } = parkingSlice.actions;
export default parkingSlice.reducer;