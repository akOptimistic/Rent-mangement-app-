import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { Utility } from '../../types';

interface UtilitiesState {
  utilities: Utility[];
  loading: boolean;
  error: string | null;
}

const initialState: UtilitiesState = {
  utilities: [],
  loading: false,
  error: null,
};

const utilitiesSlice = createSlice({
  name: 'utilities',
  initialState,
  reducers: {
    addUtility: (state, action: PayloadAction<Utility>) => {
      state.utilities.push(action.payload);
    },
    updateUtility: (state, action: PayloadAction<Utility>) => {
      const index = state.utilities.findIndex(u => u.id === action.payload.id);
      if (index !== -1) {
        state.utilities[index] = action.payload;
      }
    },
    removeUtility: (state, action: PayloadAction<string>) => {
      state.utilities = state.utilities.filter(u => u.id !== action.payload);
    },
  },
});

export const { addUtility, updateUtility, removeUtility } = utilitiesSlice.actions;
export default utilitiesSlice.reducer;