import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { Tenant } from '../../types';

interface TenantsState {
  tenants: Tenant[];
  loading: boolean;
  error: string | null;
}

const initialState: TenantsState = {
  tenants: [],
  loading: false,
  error: null,
};

const tenantsSlice = createSlice({
  name: 'tenants',
  initialState,
  reducers: {
    addTenant: (state, action: PayloadAction<Tenant>) => {
      state.tenants.push(action.payload);
    },
    updateTenant: (state, action: PayloadAction<Tenant>) => {
      const index = state.tenants.findIndex(t => t.id === action.payload.id);
      if (index !== -1) {
        state.tenants[index] = action.payload;
      }
    },
    removeTenant: (state, action: PayloadAction<string>) => {
      state.tenants = state.tenants.filter(t => t.id !== action.payload);
    },
  },
});

export const { addTenant, updateTenant, removeTenant } = tenantsSlice.actions;
export default tenantsSlice.reducer;