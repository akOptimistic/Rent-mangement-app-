import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { RentCollection } from '../../types';

interface RentCollectionsState {
  collections: RentCollection[];
  loading: boolean;
  error: string | null;
}

const initialState: RentCollectionsState = {
  collections: [],
  loading: false,
  error: null,
};

const rentCollectionsSlice = createSlice({
  name: 'rentCollections',
  initialState,
  reducers: {
    addCollection: (state, action: PayloadAction<RentCollection>) => {
      state.collections.push(action.payload);
    },
    updateCollection: (state, action: PayloadAction<RentCollection>) => {
      const index = state.collections.findIndex(c => c.id === action.payload.id);
      if (index !== -1) {
        state.collections[index] = action.payload;
      }
    },
    removeCollection: (state, action: PayloadAction<string>) => {
      state.collections = state.collections.filter(c => c.id !== action.payload);
    },
  },
});

export const { addCollection, updateCollection, removeCollection } = rentCollectionsSlice.actions;
export default rentCollectionsSlice.reducer;