import { configureStore } from '@reduxjs/toolkit';
import tenantsReducer from './slices/tenantsSlice';
import unitsReducer from './slices/unitsSlice';
import rentCollectionsReducer from './slices/rentCollectionsSlice';
import utilitiesReducer from './slices/utilitiesSlice';
import parkingReducer from './slices/parkingSlice';

export const store = configureStore({
  reducer: {
    tenants: tenantsReducer,
    units: unitsReducer,
    rentCollections: rentCollectionsReducer,
    utilities: utilitiesReducer,
    parking: parkingReducer,
  },
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;