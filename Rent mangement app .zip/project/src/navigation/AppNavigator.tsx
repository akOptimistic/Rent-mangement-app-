import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import Dashboard from '../screens/Dashboard';
import TenantsScreen from '../screens/TenantsScreen';
import UnitsScreen from '../screens/UnitsScreen';
import RentCollectionsScreen from '../screens/RentCollectionsScreen';
import UtilitiesScreen from '../screens/UtilitiesScreen';
import ParkingScreen from '../screens/ParkingScreen';

const Tab = createBottomTabNavigator();
const Stack = createNativeStackNavigator();

const TabNavigator = () => {
  return (
    <Tab.Navigator>
      <Tab.Screen name="Dashboard" component={Dashboard} />
      <Tab.Screen name="Tenants" component={TenantsScreen} />
      <Tab.Screen name="Units" component={UnitsScreen} />
      <Tab.Screen name="Collections" component={RentCollectionsScreen} />
      <Tab.Screen name="Utilities" component={UtilitiesScreen} />
      <Tab.Screen name="Parking" component={ParkingScreen} />
    </Tab.Navigator>
  );
};

const AppNavigator = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen 
          name="MainTabs" 
          component={TabNavigator} 
          options={{ headerShown: false }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default AppNavigator;